import React, { useEffect, useRef, useState } from 'react';
import { Code, Database, Palette, Settings } from 'lucide-react';

const Skills = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [animatedBars, setAnimatedBars] = useState<boolean[]>([]);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          // Animate progress bars with delay
          setTimeout(() => {
            setAnimatedBars(new Array(skillCategories.reduce((acc, cat) => acc + cat.skills.length, 0)).fill(true));
          }, 500);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const skillCategories = [
    {
      title: "Programming Languages",
      icon: <Code className="w-6 h-6" />,
      skills: [
        { name: "C", level: 85 },
        { name: "Java", level: 80 },
        { name: "Python", level: 85 },
        { name: "HTML", level: 95 },
        { name: "CSS", level: 90 },
        { name: "JavaScript", level: 85 }
      ]
    },
    {
      title: "Web Development (MERN Stack)",
      icon: <Database className="w-6 h-6" />,
      skills: [
        { name: "React.js", level: 80 },
        { name: "Node.js", level: 75 },
        { name: "Express.js", level: 75 },
        { name: "MongoDB", level: 70 },
        { name: "RESTful APIs", level: 75 },
        { name: "JavaScript", level: 85 }
      ]
    },
    {
      title: "Cybersecurity / Ethical Hacking",
      icon: <Settings className="w-6 h-6" />,
      skills: [
        { name: "Network Security", level: 80 },
        { name: "OWASP Top 10", level: 75 },
        { name: "Vulnerability Scanning", level: 70 },
        { name: "Kali Linux", level: 75 },
        { name: "Burp Suite", level: 70 }
      ]
    },
    {
      title: "Security Tools",
      icon: <Settings className="w-6 h-6" />,
      skills: [
        { name: "Nmap", level: 75 },
        { name: "Wireshark", level: 70 },
        { name: "Metasploit Framework", level: 65 }
      ]
    }
  ];

  let skillIndex = 0;

  return (
    <section id="skills" ref={sectionRef} className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`transition-all duration-1000 transform ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              My <span className="bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">Skills</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-400 to-teal-400 mx-auto rounded-full"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {skillCategories.map((category, categoryIndex) => (
              <div
                key={categoryIndex}
                className={`bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300 ${
                  isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                }`}
                style={{ transitionDelay: `${categoryIndex * 200}ms` }}
              >
                <div className="flex items-center mb-6">
                  <div className="bg-gradient-to-r from-blue-600 to-teal-600 p-3 rounded-lg text-white mr-4">
                    {category.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-white">{category.title}</h3>
                </div>

                <div className="space-y-4">
                  {category.skills.map((skill, index) => {
                    const currentSkillIndex = skillIndex++;
                    return (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-white/90 font-medium">{skill.name}</span>
                          <span className="text-white/70 text-sm">{skill.level}%</span>
                        </div>
                        <div className="bg-white/20 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-teal-500 h-full rounded-full transition-all duration-1000 ease-out"
                            style={{
                              width: animatedBars[currentSkillIndex] ? `${skill.level}%` : '0%',
                              transitionDelay: `${currentSkillIndex * 100}ms`
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;