import React, { useEffect, useRef, useState } from 'react';
import { User, Heart, Target, Star } from 'lucide-react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const highlights = [
    {
      icon: <Target className="w-6 h-6" />,
      title: "Problem Solver",
      description: "I love tackling complex challenges and finding elegant solutions"
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Team Player",
      description: "Collaborative approach with strong communication skills"
    },
    {
      icon: <Star className="w-6 h-6" />,
      title: "Continuous Learner",
      description: "Always exploring new technologies and best practices"
    }
  ];

  return (
    <section id="about" ref={sectionRef} className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`transition-all duration-1000 transform ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">Me</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-400 to-teal-400 mx-auto rounded-full"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300">
                <div className="flex items-center mb-6">
                  <User className="w-8 h-8 text-blue-400 mr-3" />
                  <h3 className="text-2xl font-semibold text-white">Professional Summary</h3>
                </div>
                
                <p className="text-white/80 leading-relaxed mb-6">
                  I am a B.Tech Computer Science and Engineering (Cyber Security) student with practical 
                  experience in cybersecurity and web development. I have completed virtual internships 
                  with leading companies like Palo Alto Networks and Zscaler, gaining hands-on experience 
                  in network security, threat prevention, and incident response.
                </p>
                
                <p className="text-white/80 leading-relaxed">
                  My expertise includes developing responsive web applications, implementing cybersecurity 
                  protocols, and working with enterprise-grade security tools. I am passionate about 
                  cybersecurity, ethical hacking, and building secure, scalable web applications using 
                  modern development practices.
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {highlights.map((item, index) => (
                <div
                  key={index}
                  className={`bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 transform hover:scale-105 ${
                    isVisible ? 'translate-x-0 opacity-100' : 'translate-x-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 200}ms` }}
                >
                  <div className="flex items-start space-x-4">
                    <div className="bg-gradient-to-r from-blue-600 to-teal-600 p-3 rounded-lg text-white">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="text-xl font-semibold text-white mb-2">{item.title}</h4>
                      <p className="text-white/70">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;