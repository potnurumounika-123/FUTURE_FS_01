import React, { useEffect, useRef, useState } from 'react';
import { GraduationCap, Award, BookOpen } from 'lucide-react';

const Education = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const education = [
    {
      degree: "Bachelor of Technology (B.Tech)",
      field: "Computer Science and Engineering (Cyber Security)",
      institution: "Chalapathi Institute of Engineering and Technology",
      location: "India",
      period: "Oct 2022 - Mar 2026",
      grade: "8.60/10 GPA",
      achievements: [
        "Specializing in Cybersecurity with focus on network security and ethical hacking",
        "Maintaining excellent academic performance with 8.60 GPA",
        "Completed virtual internships with leading cybersecurity companies",
        "Active in cybersecurity research and practical implementations"
      ]
    }
  ];

  const certifications = [
    "Certified Ethical Hacker - ECCouncil"
  ];

  return (
    <section id="education" ref={sectionRef} className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`transition-all duration-1000 transform ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Education & <span className="bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">Certifications</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-400 to-teal-400 mx-auto rounded-full"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {education.map((edu, index) => (
              <div
                key={index}
                className={`bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-500 transform hover:scale-105 ${
                  isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                }`}
                style={{ transitionDelay: `${index * 300}ms` }}
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="bg-gradient-to-r from-blue-600 to-teal-600 p-3 rounded-lg">
                    <GraduationCap className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-right">
                    <div className="text-blue-400 font-semibold">{edu.grade}</div>
                    <div className="text-white/70 text-sm">{edu.period}</div>
                  </div>
                </div>

                <h3 className="text-xl font-semibold text-white mb-2">{edu.degree}</h3>
                <h4 className="text-blue-400 font-medium mb-2">{edu.field}</h4>
                <p className="text-white/80 mb-1">{edu.institution}</p>
                <p className="text-white/70 text-sm mb-4">{edu.location}</p>

                <div className="space-y-2">
                  <h5 className="text-white font-medium text-sm flex items-center">
                    <Award className="w-4 h-4 mr-2 text-teal-400" />
                    Achievements:
                  </h5>
                  <ul className="space-y-1">
                    {edu.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="text-white/70 text-sm flex items-start">
                        <span className="text-teal-400 mr-2">•</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>

          {/* Certifications */}
          <div className={`bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 transition-all duration-700 transform ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`} style={{ transitionDelay: '600ms' }}>
            <div className="flex items-center mb-6">
              <div className="bg-gradient-to-r from-blue-600 to-teal-600 p-3 rounded-lg mr-4">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-white">Professional Certifications</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {certifications.map((cert, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-blue-600/20 to-teal-600/20 rounded-lg p-4 border border-blue-400/30 hover:from-blue-600/30 hover:to-teal-600/30 transition-all duration-300"
                >
                  <div className="flex items-center">
                    <Award className="w-5 h-5 text-blue-400 mr-3" />
                    <span className="text-white font-medium">{cert}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;