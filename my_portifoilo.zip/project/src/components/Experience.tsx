import React, { useEffect, useRef, useState } from 'react';
import { Briefcase, Calendar, MapPin } from 'lucide-react';

const Experience = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const experiences = [
    {
      title: "Virtual Intern",
      company: "Zscaler, Networking",
      location: "Remote",
      period: "Oct 2024 - Dec 2024",
      description: "Gained expertise in Zero Trust principles and cloud-native security solutions, working with enterprise-grade networking tools and security protocols.",
      achievements: [
        "Understood and applied Zero Trust principles in 10+ lab-based scenarios securing cloud-first environments and remote endpoints",
        "Demonstrated the impact of cloud-native security by improving hypothetical enterprise traffic flow, showcasing improved performance through Zscaler's architecture",
        "Completed real-world use cases simulating the transition from legacy network models to cloud-delivered security",
        "Enhanced awareness of scalable risk mitigation strategies"
      ]
    },
    {
      title: "Virtual Intern",
      company: "Palo Alto Networks, CyberSecurity",
      location: "Remote",
      period: "Jan 2024 - Mar 2024",
      description: "Completed comprehensive cybersecurity training covering threat prevention, network security, and incident response using enterprise-grade security tools.",
      achievements: [
        "Completed hands-on internship covering threat prevention, network security, and incident response using Palo Alto's enterprise-grade tools",
        "Simulated and resolved over 20+ traffic log analysis and 15+ firewall configuration exercises to strengthen network defense protocols",
        "Participated in incident response scenarios, reducing mock threat response times through efficient log review and rule tuning",
        "Gained practical experience with enterprise security tools and protocols"
      ]
    }
  ];

  return (
    <section id="experience" ref={sectionRef} className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className={`transition-all duration-1000 transform ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Work <span className="bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">Experience</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-400 to-teal-400 mx-auto rounded-full"></div>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-4 md:left-1/2 md:transform md:-translate-x-0.5 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-400 to-teal-400"></div>

            <div className="space-y-12">
              {experiences.map((exp, index) => (
                <div
                  key={index}
                  className={`relative flex flex-col md:flex-row md:items-center ${
                    index % 2 === 0 ? 'md:flex-row-reverse' : ''
                  } transition-all duration-700 transform ${
                    isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 300}ms` }}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-4 md:left-1/2 md:transform md:-translate-x-1/2 w-4 h-4 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full border-4 border-slate-900 z-10"></div>

                  {/* Content */}
                  <div className={`ml-12 md:ml-0 md:w-5/12 ${index % 2 === 0 ? 'md:mr-8' : 'md:ml-8'}`}>
                    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300 transform hover:scale-105">
                      <div className="flex items-start justify-between mb-4">
                        <div className="bg-gradient-to-r from-blue-600 to-teal-600 p-2 rounded-lg">
                          <Briefcase className="w-5 h-5 text-white" />
                        </div>
                        <div className="text-right">
                          <div className="flex items-center text-white/70 text-sm mb-1">
                            <Calendar className="w-4 h-4 mr-1" />
                            {exp.period}
                          </div>
                          <div className="flex items-center text-white/70 text-sm">
                            <MapPin className="w-4 h-4 mr-1" />
                            {exp.location}
                          </div>
                        </div>
                      </div>

                      <h3 className="text-xl font-semibold text-white mb-2">{exp.title}</h3>
                      <h4 className="text-blue-400 font-medium mb-3">{exp.company}</h4>
                      <p className="text-white/80 mb-4 leading-relaxed">{exp.description}</p>

                      <div className="space-y-2">
                        <h5 className="text-white font-medium text-sm">Key Achievements:</h5>
                        <ul className="space-y-1">
                          {exp.achievements.map((achievement, achIndex) => (
                            <li key={achIndex} className="text-white/70 text-sm flex items-start">
                              <span className="text-teal-400 mr-2">•</span>
                              {achievement}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;